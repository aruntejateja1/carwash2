package com.example.demo;

import java.sql.SQLIntegrityConstraintViolationException;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

    
	@Controller
	public class AppController {
		@Autowired
		JdbcTemplate jdbcTemplate;
	    
	    
	    @GetMapping("registerPage")
	    public String registerPage(@ModelAttribute Employee employee) {
	        
	        return "register";//go to register page.
	    }
	    
	    
	    @PostMapping("registerUser") //in register page
	    public String registerUser(@Valid @ModelAttribute Employee employee, BindingResult result,Model model) {
	        
	        if(result.hasErrors()) {
	            return "register";
	        }
	        
	        model.addAttribute("emp",employee);
	   
	        jdbcTemplate.update("insert into employee values(?,?,?)",employee.getId(),employee.getName(),employee.getSalary());
	        
	        return "success";
	    }
	    
	    
	    @GetMapping("deleteUser")
	    public String deletePage() {
	    	return "deleteForm";
	    }
	    
	    
	    @GetMapping("deleteEmp")
	    public String deleteEmployee(int id) throws UserNotFoundException {
	    	//System.out.println("from delete Employee "+id);
	    	int status=jdbcTemplate.update("delete from employee where employee_id=(?)",id);
	    	
	    	
	    	System.out.println(status);
	    	
	    	if(status==0) {
	    		throw new UserNotFoundException(id +"  does not exists");
	    	}
	    	
	    	return "deleteConfirm";
	    }
	    
	    
	    
	    @GetMapping("updateUser")
	    public String updateUser() {
	    	return "update";
	    }
	     
	    @PostMapping("updateEmp")
	    public String updateEmployee(int id,String name,String salary,int id1) {
			/*
			 * List<Map<String, Object>> id1; String
			 * sql="select employee_id from employee where employee_id=(?)";
			 * id1=jdbcTemplate.queryForList(sql,id); System.out.println(id1);
			 */
	    	
	    //	jdbcTemplate.execute("select employee_id from employee where employee_id=id");
	        jdbcTemplate.update("Update Employee set employee_name=(?) where employee_id=(?)",name,id);
	        jdbcTemplate.update("Update Employee set employee_id=(?) where employee_id=(?)",id1,id);
	        jdbcTemplate.update("Update Employee set salary=(?) where employee_id=(?)",salary,id);
	    	return "updateConfirm";
	    }
	    
	    
	        @ExceptionHandler(SQLIntegrityConstraintViolationException.class)
	        public String handleDuplicateId() {
	            
	            return "error";
	        }
	    }


