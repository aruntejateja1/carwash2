package com.example.demo;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class LoginController {
	
@GetMapping("index")
	public String showLogin(@ModelAttribute User user) { //here we are giving user to User class.
		return "index";
	}


@PostMapping("loginUser")
public String loginUser(@ModelAttribute User user,Model model) {
	if(!(user.getName().equals("abc")&&user.getPassword().equals("cts"))) {
		model.addAttribute("error","Invalid Credentials ");
		return "index";
	}
	
	model.addAttribute("name",user.getName());
	return "home";
}
}
