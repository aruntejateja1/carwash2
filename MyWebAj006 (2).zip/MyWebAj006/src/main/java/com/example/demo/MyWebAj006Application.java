package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MyWebAj006Application {

	public static void main(String[] args) {
		SpringApplication.run(MyWebAj006Application.class, args);
	}

}
