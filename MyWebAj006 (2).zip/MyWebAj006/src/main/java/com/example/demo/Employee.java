package com.example.demo;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Pattern;

public class Employee {
    @Min(value = 100,message = "Greater than 100")
    private int id;
    
    @NotEmpty(message = "Name is mandatory")
    @Pattern(regexp = "[a-z]{3,10}", message = "small case >2 and <11")
    private String name;
    
    @Min(value=25000,message="Greater than 25000")
    @Max(value=100000, message="Less then 1 lac")
    private int salary;
    
    
    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public int getSalary() {
        return salary;
    }
    public void setSalary(int salary) {
        this.salary = salary;
    }
}
