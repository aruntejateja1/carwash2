package com.example.demo;

import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice
public class AppExceptions {
	@ExceptionHandler(UserNotFoundException.class)
public String idNotFound(UserNotFoundException e) {
	System.out.println(e.getMessage());
	return "error2";
	
}
}
